# Modelo de Dados — Registro de Decisões

**Projeto:** Los Santos Customs · **Base:** requisitos v1.3 · **Início:** 24/09/2026
Decisões tomadas na modelagem de dados (seção 13, passo 2). Numeração DM para não colidir com as decisões de negócio (D1–D81).

## Arquitetura de dados

| ID | Decisão |
|----|---------|
| DM1 | Consistência escolhida por contexto segundo o PACELC (tabela abaixo) |
| DM2 | Microsserviços **por domínio**, cada um dono do seu banco lógico. Agrupamento em deploy fica para a arquitetura de soluções |
| DM3 | Sem chave estrangeira entre domínios: outro domínio guarda só o id, e a integridade é mantida por evento. Coordenação entre domínios por **saga** |
| DM4 | Persistência **poliglota**: YugabyteDB (YSQL) nos domínios de consistência forte; **Cassandra** em Execução, Histórico técnico, Auditoria e Notificações |
| DM5 | Eventos entre serviços por **outbox transacional + CDC** (Debezium → Kafka) nos domínios YugabyteDB. Nos domínios Cassandra, o mecanismo de publicação fica para a arquitetura (sem transação dado + outbox) |
| DM6 | Entidades de uma franquia são geo-particionadas pela região da franquia; dados da rede ficam globais. Regiões apenas no Brasil (LGPD) |
| DM7 | Um ER em PlantUML por domínio; domínios Cassandra modelados por consulta (diagrama Chebotko) |

### Consistência por contexto (PACELC)

| Contexto | PACELC |
|---|---|
| Contrato, sinal, pagamento final, devolução Pix | PC/EC |
| Estado da OS | PC/EC, local à franquia |
| Estoque e pedido a fornecedor | PC/EC, local |
| Lançamentos de execução | PA/EL (offline no tablet + append-only) |
| Histórico técnico e alertas de risco | PA/EL |
| Catálogo, preços e parâmetros | PA/EL com versão gravada no orçamento |
| Cadastro global de cliente | PC/EC na criação, EL na leitura |
| Saldo de cashback | PC/EC global, com reserva |
| Compensação de garantia e fechamento | EC em lote |
| Auditoria | PA/EL sem perda |
| Portal e notificações | PA/EL |

## Domínios

| ID | Decisão |
|----|---------|
| DM8 | **Cashback com reserva**: o valor é reservado no saldo global ao abrir o pagamento final; a reserva é consumida na aprovação ou liberada no cancelamento/expiração. Prazo de expiração vira parâmetro da matriz |
| DM9 | **Execução offline** só para instabilidade de rede. Registros de fato (horas, peças, fotos, etapas) são sempre aceitos, marcados como tardios se chegarem fora de "Em execução"; comandos (iniciar, concluir, adicional, falta de peça) são validados contra o estado atual e podem ser rejeitados por conflito. Cada registro leva id gerado no dispositivo, horário de ocorrência e de recebimento |
| DM10 | **Limite offline de 3 horas** (parâmetro da matriz): passado o limite, o tablet bloqueia comandos e aceita só registros de fato |
| DM11 | **Dados pessoais apenas no domínio de Clientes**. Os demais guardam `pessoa_id` e, no máximo, o nome de exibição |
| DM12 | Credencial de acesso do cliente ao portal fica no domínio de Identidade, ligada por `pessoa_id` |

## Domínio de Clientes

| ID | Decisão |
|----|---------|
| DM13 | **Pessoa global** na rede + **vínculo por franquia**, criado no primeiro atendimento. A RN07 é verificada pelo vínculo ou por autorização do cliente |
| DM14 | **Consentimento único para a rede**, versionado pelo termo aceito |
| DM15 | Somente **pessoa física**; **menores de 18 anos não são cadastrados** |
| DM16 | Identificação por **um documento só** (CPF, ou passaporte para estrangeiro), substituível |
| DM17 | **E-mail único na rede** |
| DM18 | **Um endereço** por pessoa |

Diagrama: `clientes.puml` (estilo em `estilo-er.iuml`).

## Domínio de Veículos

| ID | Decisão |
|----|---------|
| DM19 | **Chassi (VIN) é a chave de negócio**, único na rede. Placa e RENAVAM são opcionais e mantêm histórico de alterações |
| DM20 | O domínio tem dois armazenamentos: **cadastro no YugabyteDB** (unicidade do VIN e da propriedade exigem consistência forte) e **histórico técnico no Cassandra** |
| DM21 | **Propriedade por período**: um dono atual por veículo; a transferência encerra o período anterior e abre um novo |
| DM22 | **Dono anterior vê apenas o histórico do período em que o veículo foi dele**; o dono atual vê tudo |
| DM23 | O histórico técnico **não guarda pessoa_id** (RNF15): é uma projeção, alimentada por eventos de Execução, OS e Garantia, gravada de forma idempotente pelo id do evento, com TTL de 10 anos |

| DM24 | **Transferência de propriedade registrada pelo atendente**, quando o novo dono apresenta o documento do veículo; o dono anterior é notificado, sem precisar confirmar |
| DM25 | **VIN sempre no padrão de 17 caracteres** (ISO 3779): a rede só trabalha com veículos de fábrica preparados, não com carros montados sem chassi padrão |
| DM26 | **Exclusão de dados pessoais é sempre anonimização irreversível**, com ou sem contrato vigente (amplia a RNF14): o registro da pessoa fica sem dado pessoal e os outros domínios continuam apontando para um id válido |

| DM27 | **Chave Pix de devolução (RF58) fica em Pagamentos**, criptografada e presa à devolução em que foi usada. É a única exceção à DM11: o registro de uma transferência precisa ficar como estava no dia. Na anonimização, Pagamentos apaga a chave e mantém só o comprovante |
| DM28 | **Alertas de risco (RF05) ficam em Clientes**, como projeção alimentada por eventos de Pagamentos e Garantia, sem dado pessoal (adotado por padrão; pode ser revisto) |

Diagrama: `veiculos.puml`.

## Domínios de Rede e de Catálogo e Preços

| ID | Decisão |
|----|---------|
| DM29 | **Parâmetros da matriz versionados por vigência**: cada mudança cria um novo valor com data de início; quem consome grava o valor usado. Guarda autor e justificativa |
| DM30 | Franquia guarda **fuso horário** (prazos e horário comercial na hora local) e **região de dados** (geo-particionamento, DM6) |
| DM31 | **Mão de obra e peças separadas no orçamento**, para transparência com o cliente |
| DM32 | **Mão de obra por horas**: horas estimadas por serviço × valor-hora. O encerramento parcial (RN14) usa as horas executadas × o valor-hora gravado no orçamento |
| DM33 | **Peça vendida a custo de referência + margem** definida pela matriz na tabela de preços. O custo de referência é projetado a partir dos preços negociados em Suprimentos |
| DM34 | **Preço varia por tipo de veículo** (carro e moto): valor-hora e horas estimadas por tipo |
| DM36 | **Valor-hora por categoria de serviço** e tipo de veículo (ex.: a hora de injeção pode custar mais que a de funilaria) |
| DM37 | **Margem de peça por categoria de peça**, definida em cada versão da tabela |
| DM38 | **Fornecedor de referência por peça**, escolhido pela matriz: o custo dele é o custo de referência, garantindo preço único na rede (RN08) |
| DM35 | **Tabela de preços versionada** com data de início; publicada não é editada. O orçamento grava a versão, horas, valor-hora, custo e margem usados |

Diagramas: `rede.puml`, `catalogo.puml`.

## Domínio Comercial

| ID | Decisão |
|----|---------|
| DM39 | **Uma OS por serviço**: um orçamento com vários serviços gera **um contrato** e uma OS para cada item de serviço |
| DM40 | **Sinal único** de 10% sobre o total do contrato; a **desistência vale para o contrato inteiro** |
| DM41 | **Pagamento final único por contrato**, quando todas as OS terminam; o veículo sai uma vez só |
| DM42 | **Descontos só por campanha da matriz**, aplicados automaticamente no orçamento durante a vigência, por item. Escopo por categoria de serviço, serviço, categoria de peça ou peça; incidência em mão de obra, peça ou ambos. Não cumulativas: vale o maior desconto (adotado por padrão) |
| DM43 | **Avaliação técnica feita pelo chefe de oficina**, com quilometragem de entrada, observações, fotos e serviços recomendados, que servem de base ao orçamento |
| DM44 | **Versões do orçamento imutáveis** depois de apresentadas; itens congelam horas, valor-hora, custo, margem e campanha usados |
| DM45 | **Orçamento complementar** (RN01) é um orçamento do tipo COMPLEMENTAR ligado à OS e ao adicional. Aprovado durante a execução, soma ao pagamento final; aprovado depois, gera contrato e OS novos (D71) |
| DM46 | **Contrato congela** sinal, taxa de permanência diária e prazo de desistência vigentes na geração, e aponta para a versão do modelo de contrato usada. Assinatura digital com evidências do provedor; aceita novas tentativas |

Diagramas: `comercial.puml`; campanhas em `catalogo.puml`.

## Domínio de Ordem de Serviço

| ID | Decisão |
|----|---------|
| DM47 | **Fila ordenada pela entrada na fila** (fim do prazo de desistência). Resolve a pendência P1 |
| DM48 | **OS do mesmo veículo podem ser executadas em paralelo**, por mecânicos diferentes |
| DM49 | **Controle de qualidade por checklist** definido pela matriz, por categoria de serviço e critério (completo ou "seguro para rodar"), versionado. Cada rodada de CQ grava as respostas item a item |
| DM50 | **Atendimento do veículo**: agrupa as OS de um contrato (ou a OS de garantia) e concentra o que acontece uma vez por veículo: pronto para retirada, pagamento final, taxa de permanência, lembretes, jurídico, pátio e entrega (consequência da DM41) |
| DM51 | As três regiões de "Em execução" viram colunas da OS; toda transição é registrada em `os_transicao`, base dos indicadores (RF34) e da auditoria |

Diagrama: `os.puml` (modelo de dados; não confundir com `maquinas-de-estado/os.puml`).

## Máquinas de estado (revisão v1.4)

| ID | Decisão |
|----|---------|
| DM52 | **Máquina da OS dividida em duas**: a OS termina em Concluída, Encerrada parcialmente, Cancelada ou Desistida; pagamento final, devolução via Pix, jurídico, pátio e retirada passam para a nova máquina do **Atendimento do veículo** (`maquinas-de-estado/atendimento.puml`) |
| DM53 | Adicional aprovado com o veículo pronto e ainda na loja gera novo contrato e nova OS **no mesmo atendimento**, que volta a "Em serviço" (proposta, a confirmar) |

## Domínio de Execução

| ID | Decisão |
|----|---------|
| DM54 | **Horas por lançamento manual** ("X horas na tarefa T no dia D"), com limite de 24 h por mecânico por dia |
| DM55 | **Baixa de estoque na hora** em que a peça instalada é registrada (evento para Suprimentos) |
| DM56 | Quatro tabelas por consulta: lançamentos por OS, horas por mecânico e mês, tardios por franquia (revisão do chefe) e resultado da sincronização por dispositivo |
| DM57 | **Idempotência pela chave**: o id gerado no tablet faz parte da chave, e o reenvio regrava a mesma linha, sem transação leve. Correção é sempre um lançamento de estorno (RNF07) |

Diagrama: `execucao.puml`.

## Domínio de Pagamentos

| ID | Decisão |
|----|---------|
| DM58 | **Várias formas de pagamento por cobrança** (sinal e pagamento final): a cobrança fica aberta até a soma das transações aprovadas cobrir o devido; formas recusadas podem ser tentadas de novo e as aprovadas permanecem |
| DM59 | **Cobrança com composição explícita** (total do contrato, sinal pago, adicionais, taxa de permanência, valor não executado) e parâmetros de parcelamento e cashback congelados na abertura |
| DM60 | **Cashback é uma forma de pagamento** do pagamento final, ligada à reserva aberta com a cobrança (DM8) |
| DM61 | **Recebíveis por parcela**, com taxa da adquirente e valor líquido, base da conciliação (RF37) |
| DM62 | **Devolução com tentativas**: cada tentativa guarda a chave Pix cifrada (D100); cobrança cancelada com parte paga é desfeita pelo meio de origem (estorno no cartão, devolução Pix pelo e2e da transação, dinheiro no caixa) |
| DM63 | **Chave de idempotência** em toda transação e devolução, enviada à adquirente e ao PSP Pix |

Diagrama: `pagamentos.puml`.
| DM64 | **Sessão de caixa por operador**, com movimentos (suprimento, sangria, recebimento, troco, devolução) e conferência do fechamento pelo gerente; transação em dinheiro exige sessão aberta |
| DM65 | **Juros do parcelamento** entram no faturamento da franquia e na base de royalties e marketing |
| DM66 | **Atendimento com vários contratos** (P5 resolvida, confirma a DM53): tabela `atendimento_contrato`; o pagamento final é uma cobrança por atendimento, com uma linha de total por contrato (amplia a DM41) |

## Domínio de Cashback

| ID | Decisão |
|----|---------|
| DM67 | **Saldo por créditos**: cada atendimento quitado gera um crédito com validade própria de 12 meses; a conta guarda saldo disponível e reservado para checagem rápida |
| DM68 | **Base de cálculo sem juros** do parcelamento e sem a parcela paga com cashback |
| DM69 | **Uso consome os créditos mais antigos primeiro**, com a alocação gravada na reserva |
| DM70 | **Reserva de 30 minutos**, renovada a cada tentativa de pagamento; consumida, liberada ou expirada (saga com Pagamentos) |
| DM71 | **Extrato só por inserção**, com o saldo após cada movimento; o uso gera evento para o Fechamento ressarcir a franquia |

Diagrama: `cashback.puml`.

## Domínio de Garantia

| ID | Decisão |
|----|---------|
| DM72 | **Chamado particionado pela franquia que o abre** (a executora), com referência à franquia e à OS de origem |
| DM73 | **Elegibilidade gravada na abertura**, com os parâmetros usados; peças avaliadas pelo número de série instalado |
| DM74 | **Cobertura por indicadores** (mão de obra e/ou peça); recusa com motivo tipificado pelas exclusões da RN12 |
| DM75 | **Mão de obra sempre da franquia de origem**, inclusive na reinstalação de peça trocada pelo fornecedor |
| DM76 | **Compensação** = horas lançadas na OS de garantia × valor-hora da tabela vigente na data do reparo; uma por chamado, com competência no mês da conclusão, enviada ao Fechamento |

Diagrama: `garantia.puml`.
| DM77 | **Chamado concluído mesmo com abandono** da OS de garantia (P4 resolvida): compensação ocorre normalmente |

## Domínio de Suprimentos

| ID | Decisão |
|----|---------|
| DM78 | **Fornecedor, preço negociado e estoque mínimo são globais** (matriz); estoque, pedidos e recebimentos ficam na região da franquia |
| DM79 | **Estoque por franquia e peça**, com custo médio, e **unidade por número de série** para peças rastreáveis |
| DM80 | **Movimentos de estoque só por inserção**; a baixa por instalação é idempotente pelo id do lançamento da Execução e **pode deixar saldo negativo** (fatos sempre aceitos), gerando alerta de divergência |
| DM81 | **Estoque mínimo só alerta**; pedido de reposição é decisão do chefe |
| DM82 | **Pedido com tentativas de envio** pelo canal do fornecedor (API, portal ou e-mail); troca em garantia leva o número de série da peça defeituosa |
| DM83 | **Recebimento conferido pelo chefe** (quantidade, série, nota fiscal); só a quantidade aceita entra no estoque |

Diagrama: `suprimentos.puml`.

## Domínio de Identidade e Acesso

| ID | Decisão |
|----|---------|
| DM84 | **Um perfil por usuário**; chefe de oficina e gerente são perfis distintos. Permissões por perfil em tabela |
| DM85 | **Lotação**: colaborador em uma franquia por vez, com histórico; **franqueado** ligado a várias franquias com um login |
| DM86 | **Login próprio por mecânico**; tablet cadastrado como dispositivo da franquia, e a sessão leva o id do dispositivo usado pela Execução |
| DM87 | **Credencial do cliente sem dado pessoal**: e-mail guardado só como HMAC para o login; senha e segundo fator em tabelas comuns a colaboradores e clientes |
| DM88 | Segundo fator obrigatório para gerente, franqueado, financeiro, matriz e TI; senhas em Argon2id com bloqueio por tentativas |

Diagrama: `identidade.puml`.
| DM89 | **Quem cria quem**: matriz cria franqueados e gerentes; gerente cria atendente, mecânico, chefe e financeiro da própria loja. **Recebimento de peças segue com o chefe** (DM83 confirmada) |

## Domínio de Fechamento

| ID | Decisão |
|----|---------|
| DM90 | **Livro de lançamentos por evento** (receita, juros, devolução, cashback a reembolsar, créditos e débitos de garantia), idempotente pelo id do evento |
| DM91 | **Regime de caixa**: base = transações aprovadas no mês, inclusive a parte paga com cashback, + juros − devoluções confirmadas |
| DM92 | **Saldo a favor da franquia é pago pela matriz** no próprio mês; fatura com sentido (franquia paga ou matriz paga) |
| DM93 | **Eventos atrasados** entram no mês aberto como ajuste da competência original; percentuais congelados na apuração |

Diagrama: `fechamento.puml`.

## Domínio de Notificações

| ID | Decisão |
|----|---------|
| DM94 | **Canais**: cliente por portal, e-mail, SMS e WhatsApp (os dois últimos com opt-in); colaborador pela central do sistema e por e-mail |
| DM95 | **Avisos obrigatórios** (veículo parado, taxa de permanência, abandono) vão por todos os canais disponíveis; a tabela por referência guarda a prova de entrega por 5 anos |
| DM96 | **Sem dado pessoal**: contato buscado em Clientes ou Identidade no envio; só o destino mascarado fica gravado |
| DM97 | **Temporizadores ficam nas máquinas de OS e Atendimento**; Notificações apenas envia. Id da notificação derivado do evento, sem duplicar aviso |

## Domínio de Auditoria

| ID | Decisão |
|----|---------|
| DM98 | **Quatro consultas**: por franquia e dia, por registro, por usuário e mês, e acessos a dados pessoais por cliente |
| DM99 | **Imutável**: só inserção, cadeia de hash por franquia e dia (um gravador por franquia via partição do Kafka) e cópia diária em armazenamento WORM; TTL de 5 anos |
| DM100 | **Sem perda**: entrega ao menos uma vez pelo Kafka, idempotente pelo id do evento; nenhum dado pessoal nos campos antes/depois |

Diagramas: `notificacoes.puml`, `auditoria.puml`. Visão geral: `mapa-de-contexto.puml`.
