# Data Model — Glossary PT ↔ EN

The data model exists in two languages: `modelo-de-dados/` (Portuguese, the working version, linked to the requirements document) and `data-model/` (English, same content, with table, column and enum names ready for code). This glossary maps one to the other.

## Files

| Domain (PT) | Domain (EN) | PT file | EN file |
|---|---|---|---|
| Clientes | Customers | `clientes.puml` | `customers.puml` |
| Veículos | Vehicles | `veiculos.puml` | `vehicles.puml` |
| Rede | Network | `rede.puml` | `network.puml` |
| Catálogo e Preços | Catalog & Pricing | `catalogo.puml` | `catalog.puml` |
| Comercial | Sales | `comercial.puml` | `sales.puml` |
| Ordem de Serviço | Work Orders | `os.puml` | `work-orders.puml` |
| Execução | Execution | `execucao.puml` | `execution.puml` |
| Pagamentos | Payments | `pagamentos.puml` | `payments.puml` |
| Cashback | Cashback | `cashback.puml` | `cashback.puml` |
| Garantia | Warranty | `garantia.puml` | `warranty.puml` |
| Suprimentos | Supply | `suprimentos.puml` | `supply.puml` |
| Identidade e Acesso | Identity & Access | `identidade.puml` | `identity.puml` |
| Fechamento mensal | Monthly Closing | `fechamento.puml` | `monthly-closing.puml` |
| Notificações | Notifications | `notificacoes.puml` | `notifications.puml` |
| Auditoria | Audit | `auditoria.puml` | `audit.puml` |
| Mapa de contexto | Context map | `mapa-de-contexto.puml` | `context-map.puml` |
| Estilo | Style | `estilo-er.iuml` | `er-style.iuml` |

## Tables

| Domain | PT | EN |
|---|---|---|
| Customers | pessoa | person |
| | endereco | address |
| | vinculo_franquia | franchise_link |
| | autorizacao_acesso | access_authorization |
| | termo_consentimento | consent_terms |
| | consentimento | consent |
| | solicitacao_titular | data_subject_request |
| | alerta_risco | risk_alert |
| Vehicles | veiculo | vehicle |
| | identificacao_veiculo | vehicle_identifier |
| | propriedade | ownership |
| | historico_por_veiculo | history_by_vehicle |
| | pecas_por_veiculo | parts_by_vehicle |
| | veiculo_por_numero_serie | vehicle_by_serial_number |
| Network | franquia | franchise |
| | horario_funcionamento | opening_hours |
| | parametro | parameter |
| | parametro_valor | parameter_value |
| Catalog & Pricing | categoria_servico | service_category |
| | servico | service |
| | categoria_peca | part_category |
| | peca | part |
| | servico_peca_sugerida | service_suggested_part |
| | tabela_preco | price_table |
| | valor_hora | hourly_rate |
| | preco_servico | service_price |
| | margem_peca | part_markup |
| | custo_referencia_peca | part_reference_cost |
| | campanha_desconto | discount_campaign |
| | campanha_escopo | campaign_scope |
| Sales | avaliacao_tecnica | technical_inspection |
| | avaliacao_foto | inspection_photo |
| | avaliacao_recomendacao | inspection_recommendation |
| | orcamento | quote |
| | orcamento_versao | quote_version |
| | orcamento_item_servico | quote_service_item |
| | orcamento_item_peca | quote_part_item |
| | modelo_contrato | contract_template |
| | contrato | contract |
| | assinatura | signature |
| Work Orders | atendimento_veiculo | vehicle_visit |
| | atendimento_contrato | visit_contract |
| | ordem_servico | work_order |
| | os_transicao | work_order_transition |
| | reordenacao_fila | queue_reorder |
| | atribuicao | assignment |
| | solicitacao_movimentacao | transfer_request |
| | tarefa | task |
| | adicional | extra_work |
| | falta_peca | part_shortage |
| | checklist_modelo | checklist_template |
| | checklist_item | checklist_item |
| | controle_qualidade | quality_check |
| | cq_resposta | qc_answer |
| Execution | lancamentos_por_os | entries_by_work_order |
| | horas_por_mecanico | hours_by_mechanic |
| | tardios_por_franquia | late_entries_by_franchise |
| | sincronizacao_por_dispositivo | sync_results_by_device |
| | fila_local (tablet, SQLite) | local_queue (tablet, SQLite) |
| Payments | cobranca | charge |
| | cobranca_composicao | charge_line |
| | transacao | payment_transaction |
| | recebivel | receivable |
| | devolucao | refund |
| | devolucao_tentativa | refund_attempt |
| | sessao_caixa | cash_session |
| | movimento_caixa | cash_movement |
| Cashback | conta_cashback | cashback_account |
| | credito | cashback_credit |
| | reserva | cashback_hold |
| | reserva_alocacao | hold_allocation |
| | movimento | cashback_movement |
| Warranty | chamado_garantia | warranty_claim |
| | elegibilidade | eligibility |
| | chamado_peca | claim_part |
| | anexo | attachment |
| | contestacao | appeal |
| | compensacao | settlement |
| Supply | fornecedor | supplier |
| | preco_negociado | negotiated_price |
| | estoque_minimo | minimum_stock |
| | estoque_item | stock_item |
| | unidade_serie | serialized_unit |
| | movimento_estoque | stock_movement |
| | pedido_fornecedor | purchase_order |
| | pedido_item | purchase_order_item |
| | envio_pedido | order_dispatch |
| | recebimento | goods_receipt |
| | recebimento_item | goods_receipt_item |
| | alerta_estoque_minimo | minimum_stock_alert |
| Identity & Access | usuario | app_user |
| | lotacao | store_assignment |
| | franqueado_franquia | franchisee_franchise |
| | perfil_permissao | role_permission |
| | credencial_cliente | customer_credential |
| | senha | password |
| | fator_mfa | mfa_factor |
| | dispositivo | device |
| | sessao | session |
| Monthly Closing | lancamento_apuracao | closing_entry |
| | fechamento | monthly_closing |
| | fatura | invoice |
| Notifications | notificacoes_por_destinatario | notifications_by_recipient |
| | envios_por_notificacao | deliveries_by_notification |
| | notificacoes_por_referencia | notifications_by_reference |
| | preferencias_por_destinatario | preferences_by_recipient |
| | modelos_mensagem | message_templates |
| Audit | auditoria_por_franquia_dia | audit_by_franchise_day |
| | auditoria_por_entidade | audit_by_entity |
| | auditoria_por_usuario_mes | audit_by_user_month |
| | acessos_dados_pessoais | personal_data_access |
| All (technical) | outbox | outbox |

## Recurring terms

| PT | EN | Note |
|---|---|---|
| franquia | franchise | |
| matriz | HQ | |
| pessoa / cliente | person / customer | `person_id` everywhere |
| veículo | vehicle | |
| atendente | clerk | |
| mecânico | mechanic | |
| chefe de oficina | shop foreman | |
| gerente | manager | |
| franqueado | franchisee | |
| financeiro da franquia | franchise finance | |
| OS (ordem de serviço) | work order | |
| atendimento do veículo | vehicle visit | one stay of the vehicle at the store |
| adicional (impeditivo / não impeditivo) | extra work (blocking / non-blocking) | |
| orçamento complementar | supplementary quote | |
| avaliação técnica | technical inspection | |
| sinal | down payment | |
| pagamento final | final payment | |
| cobrança | charge | |
| devolução | refund | |
| estorno | reversal | |
| prazo de desistência / desistência | withdrawal period / withdrawal | |
| taxa de permanência | storage fee | |
| encerramento parcial | partial closure | |
| controle de qualidade (CQ) | quality check (QC) | |
| "seguro para rodar" | SAFE_TO_DRIVE | |
| fila | queue | |
| repasse / devolução ao chefe | handover / return | |
| falta de peça | part shortage | |
| lançamento | entry | |
| reserva de cashback | cashback hold | |
| chamado de garantia | warranty claim | |
| contestação | appeal | |
| compensação entre franquias | settlement between franchises | |
| pedido ao fornecedor | purchase order | |
| recebimento | goods receipt | |
| estoque mínimo | minimum stock | |
| margem | markup | |
| valor-hora | hourly rate | |
| tabela de preços | price table | |
| campanha de desconto | discount campaign | |
| fechamento mensal / competência | monthly closing / period | |
| fatura | invoice | |
| jurídico / pátio | legal / pound | |
| lotação | store assignment | |
| perfil | role | |

## Column conventions

| PT | EN |
|---|---|
| `*_em` (timestamptz) | `*_at` |
| `criado_em`, `atualizado_em` | `created_at`, `updated_at` |
| `vigente_desde`, `vigente_ate` | `valid_from`, `valid_until` |
| `versao` (optimistic lock) | `version` |
| `*_usuario_id` | `*_user_id` |
| `competencia` | `period` |
| `quilometragem` | `odometer_km` |
| `numero_serie` | `serial_number` |
| outbox: `agregado_tipo`, `agregado_id`, `tipo_evento`, `ocorrido_em`, `correlacao_id` | `aggregate_type`, `aggregate_id`, `event_type`, `occurred_at`, `correlation_id` |

**Reserved words avoided:** `user` → `app_user`; the Cassandra column `texto` became `note` rather than `text`.
