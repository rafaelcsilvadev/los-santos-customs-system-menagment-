# Los Santos Customs — Especificação

Pacote gerado em 24/09/2026.

## Conteúdo

| Pasta / arquivo | O que tem |
|---|---|
| `requisitos-v1.4.md` | Documento de requisitos atual (regras, requisitos funcionais e não funcionais, decisões D1–D117, pendências) |
| `maquinas-de-estado/` | Cinco máquinas de estado: OS, Atendimento do veículo, Adicional, Chamado de garantia e Orçamento |
| `modelo-de-dados/` | Modelo de dados em português: 15 domínios, mapa de contexto e `decisoes.md` (DM1–DM100) |
| `data-model/` | O mesmo modelo em inglês, com nomes prontos para o código, e `glossary.md` (PT ↔ EN) |

Cada pasta de diagramas tem os arquivos-fonte `.puml` e uma subpasta `imagens/` (ou `images/`) com cada diagrama em PNG e SVG, para abrir sem instalar nada.

## Como editar e renderizar os diagramas

Os `.puml` são PlantUML e usam `!include` do arquivo de estilo que está na mesma pasta (`estilo.iuml`, `estilo-er.iuml` ou `er-style.iuml`). Mantenha o arquivo de estilo junto dos diagramas.

- **VS Code:** extensão "PlantUML" (jebbs), com pré-visualização em Alt+D.
- **IntelliJ / JetBrains:** plugin "PlantUML Integration".
- **Linha de comando:** `java -jar plantuml.jar -tpng *.puml` (requer Java; as máquinas de estado precisam do Graphviz instalado).
- **Online:** plantuml.com/plantuml — cole o conteúdo do diagrama junto com o do arquivo de estilo no lugar da linha `!include`.

## Observação

As versões anteriores dos requisitos (v1.1 e v1.3) continuam no projeto do Claude; este pacote traz só a versão atual.
