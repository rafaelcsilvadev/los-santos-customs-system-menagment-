# Los Santos Customs
## Documento de Requisitos — Sistema de Administração da Rede

**Versão:** 1.4
**Data:** 24/09/2026
**Status:** requisitos fechados, máquinas de estado revisadas e modelo de dados concluído — pendente histórias de usuário e arquitetura de soluções
**Responsável:** Product Owner

---

## Controle de Versões

| Versão | Data | Alterações |
|--------|------|-----------|
| 1.0 | 22/09/2026 | Versão inicial do discovery, com 8 pontos em aberto |
| 1.1 | 22/09/2026 | Fechamento dos 8 pontos em aberto. Inclusão de garantia (RN11, RN12), veículo parado (RN13), regras de parcelamento (RN04 revisada), integração híbrida com fornecedores e parâmetros iniciais da matriz |
| 1.2 | 23/09/2026 | Identificação da marca: a rede passa a ser nomeada **Los Santos Customs** em todo o documento |
| 1.3 | 23/09/2026 | Modelagem das máquinas de estado (OS, Adicional, Garantia, Orçamento). Inclusão do prazo de carência antes da fila, validação do adicional pelo chefe, encerramento parcial, recusa tácita, abandono de veículo, OS de garantia, custo de garantia pela franquia de origem e validade do orçamento. Revisão de RN01, RN02, RN04, RN05, RN10, RN11, RN12 e RN13; novas RN14 a RN18; decisões D68 a D81; cinco novos parâmetros; seção 12 (pendências) |
| 1.4 | 24/09/2026 | Decisões de negócio surgidas na modelagem de dados: uma OS por serviço com contrato, sinal e pagamento final únicos; atendimento do veículo como nova máquina de estados; descontos por campanha da matriz; precificação por horas e por custo + margem; avaliação técnica pelo chefe; controle de qualidade por checklist; horas por lançamento manual; cadastro restrito a pessoa física maior de idade; VIN obrigatório; propriedade do veículo por período; exclusão de dados por anonimização; limite de 3 h offline. Pendências P1, P4 e P5 resolvidas. Revisão de RN04, RN05, RN06, RN08, RN09, RN13, RNF06 e RNF14; novas RN19 a RN22; decisões D82 a D117; novos parâmetros; seção 14 (modelo de dados) |

---

## 1. Visão Geral

### 1.1 Contexto
A **Los Santos Customs** é uma rede nacional de oficinas especializadas em **customização e preparação pesada de carros e motos**, com foco em veículos preparados para corridas de rua. A estrutura é composta por **2.500 franquias** espalhadas pelo país e uma **matriz na cidade de Los Santos**, somando mais de **50.000 colaboradores**, de mecânicos a atendentes.

Ao longo deste documento, "a Rede" e "a matriz" referem-se, respectivamente, ao conjunto das franquias Los Santos Customs e à sua sede administrativa.

### 1.2 Problema
Hoje a operação é controlada por **planilhas**, com contratos e registros de serviço dispersos entre as unidades. Isso gera três dores centrais:

1. **Contratos descentralizados e sem padrão**, difíceis de auditar e de usar como defesa em caso de disputa.
2. **Histórico de serviço não confiável**, o que é crítico num segmento onde cada peça instalada tem impacto em garantia, segurança e valor de revenda.
3. **Ausência de um mecanismo estruturado de fidelidade**, sem visão unificada do cliente na rede.

### 1.3 Objetivo do produto
Construir uma plataforma corporativa que padronize a operação das 2.500 franquias Los Santos Customs, garanta rastreabilidade completa do que foi feito em cada veículo, digitalize contratos e pagamentos e sustente um programa de fidelidade em nível de rede.

### 1.4 Escopo

**Dentro do escopo**
- Cadastro unificado de clientes e veículos em toda a rede
- Orçamento, contrato com assinatura digital e gestão de pagamentos
- Registro de execução dos serviços pelos mecânicos
- Estoque e pedidos a fornecedores parceiros
- Gestão de garantia em nível de rede
- Programa de cashback
- Backoffice para franqueado e matriz
- Portal do cliente (web e mobile) e site institucional
- Conformidade com LGPD

**Fora do escopo**
- Regularização veicular, inspeções e integração com órgãos de trânsito
- Pagamento online — todos os pagamentos ocorrem na loja (D29)
- Transferência de peças entre unidades (D23)
- Reserva de capacidade no agendamento online — o agendamento é uma solicitação de contato (D66)
- Condução do processo jurídico de veículo abandonado e custódia em pátio — o sistema apenas registra os eventos (D74)
- Atendimento a pessoa jurídica e a menores de 18 anos (D86)
- Veículos sem número de chassi (VIN) no padrão de 17 caracteres (D88)

---

## 2. Produtos da Plataforma

| # | Produto | Público | Finalidade |
|---|---------|---------|-----------|
| P1 | **Sistema do Atendente** | Atendente / consultor | Cadastro de cliente e veículo, orçamento, contrato, recebimento |
| P2 | **Sistema do Mecânico** | Mecânico e chefe de oficina | Avaliação técnica, registro de execução, peças, horas e evidências, controle de qualidade |
| P3 | **Portal do Cliente** | Cliente final | Acompanhamento, aprovações, histórico e cashback |
| P4 | **Backoffice** | Franqueado e matriz | Gestão da unidade e da rede |
| P5 | **Site Institucional** | Público geral | Vitrine, catálogo, localizador e captação |

---

## 3. Personas e Perfis de Acesso

| Perfil | Escopo | Principais responsabilidades |
|--------|--------|------------------------------|
| **Atendente** | Loja | Cadastrar cliente e veículo, registrar transferência de propriedade, montar orçamento, gerar contrato, receber pagamento, abrir chamado de garantia |
| **Mecânico** | Loja | Registrar execução, peças, horas e fotos; solicitar adicionais e repasses |
| **Chefe de oficina** | Loja | Realizar a avaliação técnica, atribuir mecânicos, ordenar a fila, validar adicionais, pedir peças, executar o controle de qualidade, avaliar garantia |
| **Gerente** | Loja | Cuidar da operação da loja: acompanhar desempenho, financeiro, estoque e equipe; criar e desativar usuários da unidade; conferir o fechamento de caixa; encaminhar veículos abandonados ao jurídico |
| **Franqueado** | Suas lojas | Dono de uma ou mais franquias, com um único login: acompanhar desempenho e financeiro de todas as suas lojas |
| **Financeiro da franquia** | Loja | Contas a receber, conciliação, fechamento mensal com a matriz |
| **Matriz** | Rede | Parâmetros globais, catálogo, tabela de preços, campanhas de desconto, checklists de qualidade, ranking, auditoria, cadastro de franquias, decisão sobre garantias contestadas |
| **Administrador de TI** | Rede | Acessos críticos, integrações, suporte |
| **Cliente** | Portal | Acompanhar serviço, aprovar adicionais, consultar histórico e cashback, acionar garantia |

---

## 4. Jornada do Serviço (fluxo principal)

1. **Chegada** — cliente chega à loja ou solicita contato pelo site/portal
2. **Cadastro** — atendente localiza ou cadastra cliente e veículo
3. **Avaliação técnica** — o chefe de oficina avalia o veículo, registra quilometragem de entrada, observações, fotos e serviços recomendados
4. **Orçamento** — montado pelo atendente a partir do catálogo e da tabela de preços da matriz, com mão de obra e peças separadas e prazo de validade
5. **Aprovação e contrato** — cliente aprova, assina digitalmente um contrato único para todos os serviços e paga 10% de sinal à vista, sem sair da loja antes do pagamento
6. **Prazo de desistência** — 24 horas de carência; só depois cada serviço entra na fila do chefe como uma OS própria
7. **Execução** — chefe atribui mecânicos a cada OS; as OS do mesmo veículo podem correr em paralelo; a execução começa quando o mecânico inicia o trabalho; mecânicos registram etapas, peças e horas
8. **Controle de qualidade** — realizado pelo chefe de oficina em cada OS, por checklist da matriz
9. **Pagamento e entrega** — quando todas as OS do contrato terminam, o cliente quita o saldo e retira o veículo
10. **Pós-venda** — garantia, cashback e histórico atualizado

---

## 5. Requisitos Funcionais

### 5.1 Sistema do Atendente (P1)

- **RF01** Cadastrar e consultar clientes pessoa física maiores de 18 anos, identificando-os por um documento (CPF ou, para estrangeiros, passaporte) e por e-mail, ambos únicos na rede.
- **RF02** Alertar o atendente quando já existir cadastro para o documento ou e-mail informado, evitando duplicidade.
- **RF03** Cadastrar veículos (carro ou moto) identificados pelo chassi (VIN), vinculados ao cliente, com histórico próprio. Placa e RENAVAM mantêm histórico de alterações.
- **RF04** Consultar o histórico técnico de qualquer veículo da rede, independentemente da unidade de origem.
- **RF05** Exibir alertas de risco de outras unidades (pendência financeira, contestação de garantia) sem expor dados pessoais completos do cliente.
- **RF06** Montar orçamento exclusivamente a partir do catálogo e da tabela de preços definidos pela matriz, com mão de obra e peças separadas, aplicação automática das campanhas de desconto vigentes, versionamento a cada alteração e controle de validade.
- **RF07** Gerar contrato a partir do orçamento aprovado e dentro da validade, com assinatura digital do cliente. Um contrato cobre todos os serviços do orçamento.
- **RF08** Registrar o pagamento do sinal de 10% à vista (cartão, dinheiro ou Pix), permitindo novas tentativas em caso de transação recusada, e iniciar o prazo de desistência.
- **RF09** Registrar o pagamento final do atendimento do veículo, quando todas as suas OS estiverem concluídas ou encerradas parcialmente, aplicando cashback, adicionais aprovados durante a execução e taxa de permanência, se houver.
- **RF10** Registrar desistência dentro do prazo e a devolução do sinal via Pix.
- **RF11** Criar e desativar usuários da própria unidade (perfil Gerente): atendente, mecânico, chefe de oficina e financeiro. Franqueados e gerentes são criados pela matriz.
- **RF57** Simular o parcelamento do saldo, apresentando ao cliente o número de parcelas, a incidência de juros e o valor final, conforme os parâmetros da matriz.
- **RF58** Registrar a chave Pix do cliente no momento da desistência ou da retirada com saldo a devolver, para efetuar a devolução.
- **RF59** Abrir chamado de garantia para um serviço executado em qualquer unidade da rede, exibindo a elegibilidade calculada (prazo, quilometragem e tipo de encerramento do serviço original) em caráter informativo.
- **RF69** Cancelar um contrato assinado cujo sinal não foi pago.
- **RF81** Abrir e fechar a sessão de caixa do atendente, registrando suprimentos, sangrias, recebimentos, trocos e devoluções em dinheiro; no fechamento, comparar o valor contado com o esperado, com conferência da diferença pelo gerente.
- **RF76** Registrar a transferência de propriedade de um veículo quando o novo dono apresentar o documento do veículo, notificando o dono anterior.

### 5.2 Sistema do Mecânico (P2)

- **RF12** Exibir ao mecânico apenas os veículos e tarefas atribuídos a ele.
- **RF13** Permitir ao chefe de oficina atribuir um ou vários mecânicos a cada OS, indicando o responsável. A atribuição não inicia a execução.
- **RF14** Apresentar ao chefe a fila de OS ordenada pela data de entrada na fila (fim do prazo de desistência).
- **RF15** Permitir ao chefe reordenar a fila, registrando autor e justificativa.
- **RF16** Registrar etapas concluídas, peças utilizadas (com número de série), horas trabalhadas, fotos de antes/depois e observações.
- **RF17** Permitir ao mecânico devolver o serviço ao chefe ou solicitar repasse a um colega, com decisão final do chefe.
- **RF18** Permitir ao mecânico registrar a necessidade de serviço adicional, que é submetida à validação do chefe antes de gerar orçamento complementar.
- **RF19** Classificar o adicional como impeditivo ou não impeditivo, podendo o chefe reclassificá-lo na validação.
- **RF20** Registrar o pedido de peça ao fornecedor quando houver falta de estoque.
- **RF21** Registrar o resultado do controle de qualidade por checklist da matriz e, em caso de reprovação, devolver o serviço ao mecânico responsável, podendo o chefe reatribuir. No encerramento parcial, usa-se o checklist "seguro para rodar".
- **RF82** Permitir ao chefe de oficina conferir o recebimento de peças do fornecedor (quantidade, número de série e nota fiscal), registrando divergências; só a quantidade aceita entra no estoque.
- **RF22** Operar em modo contingência offline para registro de execução, sincronizando ao restabelecer a conexão.
- **RF60** Permitir ao chefe de oficina avaliar a procedência de um chamado de garantia, consultando o serviço original e seu executor, e indicar a cobertura (mão de obra ou peça).
- **RF70** Registrar o início da execução pelo mecânico, distinto da atribuição.
- **RF71** Permitir ao chefe validar o adicional registrado pelo mecânico: aprovar, rejeitar ou reclassificar.
- **RF72** Apurar peças e horas executadas no encerramento parcial.
- **RF73** Gerar pedido de troca em garantia ao fornecedor quando a cobertura for de peça.
- **RF77** Permitir ao chefe de oficina registrar a avaliação técnica do veículo: quilometragem de entrada, observações, fotos e serviços recomendados.
- **RF78** Exibir ao chefe os lançamentos recebidos fora de "Em execução" (lançamentos tardios) para revisão, e ao mecânico o resultado da sincronização de cada registro feito offline.

### 5.3 Portal do Cliente (P3)

- **RF23** Permitir autocadastro pelo site ou aplicativo, restrito a maiores de 18 anos, com aceite do termo de consentimento.
- **RF24** Acompanhar em tempo real o status do serviço contratado.
- **RF25** Receber notificações de adicionais, falta de peça e mudanças de prazo, pelo portal, por e-mail e, com opt-in do cliente, por SMS e WhatsApp. Avisos de veículo parado, taxa de permanência e abandono vão por todos os canais disponíveis, com registro de entrega como prova.
- **RF26** Aprovar ou recusar orçamentos complementares.
- **RF27** Consultar o histórico dos seus veículos em toda a rede: o dono atual vê todo o histórico; o dono anterior vê apenas o período em que o veículo foi dele.
- **RF28** Consultar saldo, extrato e validade do cashback.
- **RF29** Exercer direitos de acesso, correção e exclusão de dados pessoais (LGPD).
- **RF30** Acessar o portal em versão web e mobile.
- **RF61** Acompanhar o andamento de chamados de garantia e contestar uma recusa dentro do prazo de contestação.
- **RF62** Receber lembretes automáticos enquanto o veículo estiver parado aguardando decisão do cliente ou pronto e não retirado, com aviso prévio sobre a taxa de permanência e sobre o encaminhamento ao jurídico.

### 5.4 Backoffice — Franqueado (P4)

- **RF31** Painel de faturamento da unidade.
- **RF32** Visão de serviços em andamento e em atraso.
- **RF33** Visão de veículos parados (em validação interna, aguardando cliente, aguardando peça ou prontos e não retirados).
- **RF34** Indicadores de produtividade por mecânico, medidos a partir do início efetivo da execução e das horas lançadas.
- **RF35** Gestão de estoque e pedidos a fornecedores parceiros.
- **RF36** Alerta automático quando o estoque atingir o mínimo definido pela matriz. O alerta não gera pedido: o chefe de oficina decide a reposição.
- **RF37** Contas a receber e conciliação de pagamentos.
- **RF38** Consulta ao fechamento mensal com a matriz.
- **RF63** Receber alerta de veículo parado há mais de 7 dias. Os alertas internos (veículo parado, estoque mínimo, adicional sem validação e demais) aparecem na central de avisos do sistema e também por e-mail.
- **RF64** Consultar os valores de cashback a ressarcir pela matriz e os créditos e débitos com outras franquias referentes a reparos em garantia.
- **RF74** Receber alerta quando um adicional exceder o prazo de validação pelo chefe.
- **RF75** Registrar o encaminhamento de veículo abandonado ao jurídico, a remoção para pátio e o desfecho da dívida.

### 5.5 Backoffice — Matriz (P4)

- **RF39** Manter o catálogo de serviços e peças e a tabela única de preços da rede, versionada e com data de início de vigência: horas estimadas por serviço e tipo de veículo, valor-hora por categoria de serviço e tipo de veículo, e margem por categoria de peça.
- **RF40** Homologar fornecedores parceiros, manter os preços negociados das peças e definir o fornecedor de referência de cada peça.
- **RF41** Definir o estoque mínimo por peça.
- **RF42** Configurar as regras do programa de cashback.
- **RF43** Configurar os percentuais de royalties e taxa de marketing.
- **RF44** Gerar o fechamento mensal por franquia, com fatura única.
- **RF45** Exibir ranking e comparação de desempenho entre franquias.
- **RF46** Cadastrar e manter franquias.
- **RF47** Consultar a trilha de auditoria da rede por franquia e período, por registro (OS, contrato, chamado etc.) e por usuário, além dos acessos aos dados pessoais de cada cliente.
- **RF48** Acessar dados operacionais das franquias em modo somente leitura.
- **RF65** Configurar os parâmetros de parcelamento: número máximo de parcelas, faixa sem juros e taxa de juros.
- **RF66** Configurar os prazos de garantia de mão de obra, a taxa diária de permanência e os prazos da seção 7 (validação do adicional, recusa tácita, abandono, contestação de garantia, validade do orçamento e limite offline).
- **RF67** Analisar e decidir sobre chamados de garantia contestados pelo cliente.
- **RF79** Criar campanhas de desconto com percentual, vigência, incidência (mão de obra, peças ou ambos), tipo de veículo e escopo (categorias, serviços ou peças).
- **RF80** Manter os checklists de controle de qualidade por categoria de serviço, incluindo o checklist "seguro para rodar" do encerramento parcial.

### 5.6 Site Institucional (P5)

- **RF49** Vitrine institucional da marca.
- **RF50** Localizador de franquias.
- **RF51** Catálogo público de serviços com preços.
- **RF52** Registrar solicitação de contato ou orçamento online, sem reserva de capacidade da oficina.
- **RF53** Páginas "Trabalhe conosco" e "Seja um franqueado".

### 5.7 Integrações

- **RF54** Enviar automaticamente ao fornecedor parceiro os pedidos de peça gerados pelo sistema, inclusive pedidos de troca em garantia, em modelo híbrido (API, portal do fornecedor ou e-mail estruturado, conforme a capacidade do parceiro).
- **RF55** Processar assinatura digital de contratos.
- **RF56** Executar devoluções via Pix (sinal em desistência e diferença em encerramento parcial), com tratamento de falha e nova tentativa.
- **RF68** Processar transações de cartão, incluindo parcelamento com juros, com registro da aprovação.

---

## 6. Regras de Negócio

**RN01 — Serviço adicional não impeditivo** *(revisada)*
Ao identificar a necessidade de serviço adicional, o mecânico registra a ocorrência e o chefe de oficina a valida (RN17). Validado, o sistema gera um orçamento complementar e notifica o cliente pelo portal e por e-mail. Se não houver resposta em 24 horas **a partir da notificação**, o serviço prossegue no escopo contratado e o adicional permanece pendente até ser aprovado, recusado ou a OS ser encerrada. Se o cliente aprovar depois que a OS saiu de "Em execução" (em controle de qualidade ou concluída com o veículo ainda na loja), o adicional **gera uma nova OS**, reprecificada pela tabela vigente, com contrato, sinal e prazo de desistência próprios.

**RN02 — Serviço adicional impeditivo** *(revisada)*
Quando o adicional impedir a continuidade do serviço contratado, a execução é pausada desde o registro. Enquanto o chefe não valida, o veículo fica em "Em validação interna", sem contagem de taxa de permanência. Validado e notificado o cliente, o veículo passa a "Aguardando cliente" até a decisão. O adicional não expira; a recusa, expressa ou tácita (RN15), leva ao encerramento parcial (RN14).

**RN03 — Falta de peça**
Se uma peça necessária não estiver disponível, o serviço passa ao status "Aguardando peça", o chefe de oficina registra o pedido ao fornecedor parceiro pelo sistema e o cliente é notificado. O prazo previsto de entrega é atualizado. A falta de peça e a espera pelo cliente podem ocorrer ao mesmo tempo; a execução só é retomada quando as duas pendências estão resolvidas.

**RN04 — Pagamento** *(revisada na v1.4)*
O contrato cobre todos os serviços do orçamento e é ativado após a **aprovação da transação do sinal de 10% sobre o total do contrato**, pago obrigatoriamente **à vista**, em cartão, dinheiro ou Pix, antes de o cliente deixar a loja. Cada serviço entra na fila do chefe, como uma OS própria, somente **após o fim do prazo de desistência** (RN05). O **pagamento final é único por atendimento do veículo** (RN19): ocorre quando todas as OS do atendimento estão concluídas ou encerradas parcialmente, e o veículo é liberado após a **aprovação da transação do saldo**. Tanto o sinal quanto o saldo podem ser pagos **combinando mais de uma forma de pagamento**; a cobrança só é quitada quando a soma das transações aprovadas cobre o valor devido. O saldo pode ser parcelado **exclusivamente no cartão de crédito, em até 12 parcelas**, com juros. O número máximo de parcelas, a faixa sem juros e a taxa de juros são parâmetros definidos pela matriz. Os adicionais **aprovados durante a execução** somam-se ao saldo pago na entrega, assim como a taxa de permanência, quando houver. Se o saldo for negativo (RN14), a diferença é devolvida via Pix. Todos os pagamentos ocorrem na loja.

**RN05 — Desistência** *(revisada na v1.4)*
O cliente pode desistir **do contrato inteiro** em até 24 horas após a aprovação do sinal, com devolução integral do sinal, efetuada via Pix. Durante esse prazo nenhum serviço do contrato **pode ser iniciado** nem entra na fila. Após o prazo não há devolução.

**RN06 — Cashback** *(revisada na v1.4)*
Após a quitação do pagamento final do atendimento, o cliente recebe 5% em cashback, calculado sobre o valor efetivamente pago, excluídos a parcela quitada com cashback e os **juros do parcelamento**. Cada crédito é válido por 12 meses a partir da sua geração, e o uso consome **primeiro os créditos mais antigos**. O saldo vale em qualquer franquia e pode abater até 30% do pagamento final de um serviço futuro. Ao abrir o pagamento final, o valor de cashback a usar é **reservado** no saldo; a reserva é consumida na aprovação da transação, liberada se o pagamento for cancelado ou expira após 30 minutos sem nova tentativa (prazo renovado a cada tentativa). O custo é absorvido pela matriz.

**RN07 — Visibilidade entre franquias**
O histórico técnico do veículo e os alertas de risco são visíveis a toda a rede. Os dados pessoais completos do cliente só são exibidos à unidade que está prestando o atendimento ou mediante autorização do cliente. Todo acesso a dados pessoais de cliente de outra unidade é registrado em auditoria.

**RN08 — Precificação** *(revisada na v1.4)*
Os preços são definidos exclusivamente pela matriz, em tabela única para toda a rede, versionada e com data de início de vigência. A **mão de obra** é calculada por horas estimadas do serviço × valor-hora da categoria do serviço, ambos por tipo de veículo (carro ou moto). A **peça** é vendida pelo custo do fornecedor de referência definido pela matriz, acrescido da margem da categoria da peça. **Descontos só existem por campanhas da matriz**, aplicadas automaticamente no orçamento durante a vigência; campanhas não se acumulam, prevalecendo o maior desconto. O atendente não altera preços.

**RN09 — Atribuição de trabalho** *(revisada na v1.4)*
A fila de OS é ordenada pela **data de entrada na fila** (fim do prazo de desistência). O chefe de oficina atribui os mecânicos a cada OS, indicando o responsável, e pode reordenar a fila. A execução começa quando o primeiro mecânico atribuído inicia o trabalho. OS do mesmo veículo podem ser executadas **em paralelo**, por mecânicos diferentes. Devoluções e repasses de serviço são sempre decididos pelo chefe. Serviço reprovado no controle de qualidade retorna ao mecânico responsável, podendo o chefe reatribuí-lo. A OS só segue para o controle de qualidade quando todas as tarefas, inclusive as de adicionais aprovados, estão concluídas.

**RN10 — Fechamento mensal** *(revisada na v1.4)*
Mensalmente o sistema apura o faturamento de cada franquia em **regime de caixa** (transações aprovadas no mês, inclusive a parte paga com cashback, **mais os juros do parcelamento**, menos as devoluções confirmadas no mês), calcula royalties e taxa de marketing conforme os percentuais parametrizados pela matriz, abate o cashback a reembolsar e **compensa os créditos e débitos entre franquias referentes a reparos em garantia** (RN11), e emite uma fatura única. Se o saldo do mês for a favor da franquia, **a matriz paga a diferença**; não há crédito para o mês seguinte. Eventos que chegam depois da apuração entram no mês em aberto como ajuste.

**RN11 — Garantia** *(revisada na v1.4)*
A garantia é dividida em duas coberturas: **mão de obra**, de responsabilidade da **franquia que executou o serviço original**, com prazo de 90 dias ou 3.000 km (o que ocorrer primeiro); e **peça**, conforme o prazo do fabricante, rastreada pelo número de série registrado na execução. O cliente pode acionar a garantia em **qualquer franquia**. O sistema calcula a elegibilidade em caráter informativo, e o **chefe de oficina avalia a procedência** e indica a cobertura. Se procedente, o reparo é executado como uma **OS de garantia** (RN18), sem custo para o cliente. Na cobertura de peça, a peça nova é obtida por **pedido de troca em garantia ao fornecedor**. A mão de obra do reparo é sempre custeada pela franquia de origem, **inclusive a reinstalação de peça trocada pelo fornecedor**: quando o reparo é feito em outra franquia, a executora é **creditada** e a de origem **debitada** no fechamento mensal, pelo valor das **horas lançadas na OS de garantia × valor-hora da tabela vigente na data do reparo**; a matriz apenas intermedeia. Se o cliente contestar a recusa dentro do prazo de contestação, o caso é **encaminhado à matriz para decisão final**; vencido o prazo, a recusa é definitiva.

**RN12 — Exclusões de garantia** *(revisada)*
A garantia de mão de obra não cobre: uso em competição não previsto no contrato; intervenção de terceiros no componente preparado; alteração de parâmetros realizada pelo cliente; falta de manutenção prevista; e **serviço encerrado parcialmente** por recusa de adicional impeditivo (RN14). A garantia de peça do fabricante não é afetada pelo encerramento parcial.

**RN13 — Veículo parado** *(revisada na v1.4)*
Enquanto uma OS estiver com a execução pausada (em validação interna, aguardando cliente ou aguardando peça) ou o **veículo estiver pronto e não retirado** (atendimento aguardando pagamento final), o sistema notifica o cliente a cada **3 dias**. Após **7 dias** parado, alerta o gerente da unidade. A **taxa diária de permanência**, prevista em contrato e parametrizada pela matriz, incide:
- em "Aguardando cliente", após **15 dias** contados apenas enquanto **não houver peça pendente**, pois a espera simultânea por peça não é atribuível ao cliente;
- no atendimento "Aguardando pagamento final", após **15 dias** do veículo pronto (todas as OS do contrato terminadas).

A taxa **não incide** em "Em validação interna" nem em "Aguardando peça". A taxa acumulada soma-se ao saldo cobrado na retirada e deixa de correr quando o veículo é removido para pátio (RN15).

**RN14 — Encerramento parcial**
Se o cliente recusar um adicional impeditivo, expressa ou tacitamente, o serviço é interrompido e o sistema apura as peças e horas efetivamente executadas, valorizando as horas pelo valor-hora gravado no orçamento. A OS passa por **controle de qualidade de segurança**, com o checklist "seguro para rodar", e segue o fluxo normal de pagamento e retirada do atendimento. Se o valor executado for **menor que o sinal pago**, a diferença (descontada a taxa de permanência, se houver) é **devolvida via Pix** na retirada. O serviço encerrado parcialmente não tem garantia de mão de obra (RN12).

**RN15 — Recusa tácita e veículo abandonado**
Após o prazo de recusa tácita (parâmetro X) em "Aguardando cliente", o adicional impeditivo é considerado recusado e aplica-se a RN14. Após o prazo de abandono (parâmetro Y) com o veículo pronto e não retirado, o cliente é notificado e o atendimento é **encaminhado ao jurídico**. Enquanto o veículo estiver na loja, o cliente pode retirá-lo quitando saldo e taxas. Removido o veículo para pátio, a taxa de permanência deixa de correr e o atendimento é encerrado por abandono quando a dívida for quitada ou o processo concluído.

**RN16 — Validade do orçamento**
O orçamento tem validade parametrizada pela matriz, contada a partir da apresentação ao cliente. Cada alteração gera uma nova versão e reinicia o prazo. Vencida a validade, o orçamento expira e é preciso gerar um novo, com os preços vigentes. Uma versão apresentada guarda os preços usados e não é alterada.

**RN17 — Validação do adicional**
Todo adicional registrado pelo mecânico é validado pelo chefe de oficina antes de chegar ao cliente. O chefe pode aprovar, rejeitar ou reclassificar entre impeditivo e não impeditivo. Se a validação exceder o prazo parametrizado pela matriz, o gerente é alertado; o adicional não é enviado ao cliente automaticamente.

**RN18 — OS de garantia**
O reparo em garantia é executado como uma Ordem de Serviço do tipo garantia, que entra diretamente na fila, sem sinal nem prazo de desistência, e segue o mesmo ciclo de execução, controle de qualidade e retirada. Problemas não cobertos encontrados durante o reparo seguem o fluxo normal de adicional, pago pelo cliente.

**RN19 — Uma OS por serviço** *(nova)*
Cada serviço do contrato gera uma Ordem de Serviço própria, com fila, atribuição, execução, controle de qualidade e garantia independentes. As OS de um mesmo contrato formam um **atendimento do veículo**. Se um adicional for aprovado com o veículo pronto e ainda na loja, o novo contrato e sua OS entram **no mesmo atendimento**, que volta a "Em serviço". O atendimento concentra o que acontece uma vez por veículo: pagamento final, taxa de permanência do veículo pronto, lembretes, devolução via Pix, jurídico, pátio e retirada.

**RN20 — Cadastro de cliente** *(nova)*
Somente pessoas físicas maiores de 18 anos são cadastradas. O cliente é identificado por um único documento (CPF ou passaporte), substituível, e por e-mail, ambos únicos na rede. O consentimento LGPD é único para a rede, versionado pelo termo aceito. O cliente tem um cadastro global e um vínculo com cada franquia que o atende.

**RN21 — Propriedade do veículo** *(nova)*
O veículo é identificado pelo chassi (VIN) no padrão de 17 caracteres e tem um dono por vez. A transferência é registrada pelo atendente quando o novo dono apresenta o documento do veículo; o dono anterior é notificado, sem precisar confirmar. O histórico técnico acompanha o veículo: o dono atual vê todo o histórico e o dono anterior vê apenas o período em que o veículo foi dele.

**RN22 — Registro de execução** *(nova)*
O mecânico lança as horas manualmente ("X horas na tarefa T no dia D"), com limite de 24 horas por dia. O registro de peça instalada baixa o estoque da franquia na hora. Nenhum lançamento é alterado: a correção é feita por um lançamento de estorno. Registros de fato feitos offline (horas, peças, fotos, observações, etapas) são sempre aceitos, e marcados como tardios se chegarem com a OS fora de "Em execução"; comandos (iniciar, concluir tarefa, registrar adicional ou falta de peça) são validados contra o estado atual da OS e podem ser rejeitados por conflito.

---

## 7. Parâmetros de Negócio

Valores configuráveis pela matriz. Os valores abaixo são os **iniciais**, definidos para modelagem e testes, e não devem ser fixados em código. Cada alteração é versionada com data de início de vigência, autor e justificativa; quem usa um parâmetro grava o valor aplicado.

| Parâmetro | Valor inicial | Regra associada |
|---|---|---|
| Royalties | 6% do faturamento | RN10 |
| Taxa de marketing | 2% do faturamento | RN10 |
| Cashback | 5% do valor pago | RN06 |
| Validade do cashback | 12 meses | RN06 |
| Limite de uso do cashback | 30% do pagamento final | RN06 |
| Expiração da reserva de cashback | 30 minutos, renovados a cada tentativa | RN06 |
| Sinal | 10% do contrato, à vista | RN04 |
| Parcelamento máximo | 12x, somente cartão | RN04 |
| Faixa sem juros | até 3x | RN04 |
| Juros acima da faixa | 2,5% ao mês | RN04 |
| Prazo de desistência | 24 horas | RN05 |
| Prazo de resposta a adicional | 24 horas, a partir da notificação | RN01 |
| Garantia de mão de obra | 90 dias ou 3.000 km | RN11 |
| Lembrete de veículo parado | a cada 3 dias | RN13 |
| Alerta ao gerente | 7 dias | RN13 |
| Início da taxa de permanência | 15 dias | RN13 |
| Valor da taxa de permanência | a definir | RN13 |
| Estoque mínimo por peça | por peça | RN03 |
| Prazo de validação do adicional | a definir | RN17 |
| Prazo de recusa tácita (X) | a definir | RN15 |
| Prazo de abandono (Y) | a definir | RN15 |
| Prazo de contestação da garantia | a definir | RN11 |
| Validade do orçamento | a definir | RN16 |
| Limite de operação offline | 3 horas | RNF06 |
| Valor-hora por categoria de serviço e tipo de veículo | a definir, na tabela de preços | RN08 |
| Margem por categoria de peça | a definir, na tabela de preços | RN08 |

---

## 8. Requisitos Não Funcionais

### 8.1 Disponibilidade e desempenho
- **RNF01** Disponibilidade de 99,9% em horário comercial para os sistemas de loja.
- **RNF02** Tempo de resposta de até 2 segundos em telas operacionais e 5 segundos em relatórios do Backoffice.
- **RNF03** Suporte a 25.000 usuários internos simultâneos em pico, com escalabilidade horizontal.
- **RNF04** Operação multirregião, com janela de manutenção fora do horário comercial.

### 8.2 Continuidade
- **RNF05** Backup diário com retenção de 30 dias; RPO de 1 hora e RTO de 4 horas.
- **RNF06** Modo contingência offline no Sistema do Mecânico, com sincronização posterior, destinado a instabilidades de rede. Após o limite de operação offline (3 horas), o tablet bloqueia comandos e aceita apenas registros de fato até reconectar.
- **RNF07** Registro de execução incremental (cada etapa é um lançamento novo, sem sobrescrita), para evitar conflitos de sincronização.
- **RNF08** Operações dependentes de conexão — aprovação de adicional pelo cliente, pedido de peça ao fornecedor e processamento de pagamento — não operam em modo offline e devem ser bloqueadas com mensagem clara ao usuário.

### 8.3 Segurança e LGPD
- **RNF09** Autenticação com perfis e permissões por papel, senha forte e segundo fator para perfis administrativos (gerente, franqueado, financeiro, matriz e TI). Cada usuário tem um único perfil e login próprio, inclusive os mecânicos; colaboradores são lotados em uma única unidade por vez, e o franqueado acessa todas as suas lojas com um só login.
- **RNF10** Criptografia dos dados em trânsito e em repouso.
- **RNF11** Trilha de auditoria imutável, com retenção de 5 anos, cobrindo: alterações na fila, repasses e devoluções de serviço, alterações de contrato, cancelamentos, desistências e devoluções via Pix, validações de adicional, encerramentos parciais, encaminhamentos ao jurídico, uso de cashback, decisões de garantia (com a cobertura indicada), transferências de propriedade de veículo e acessos a dados pessoais de cliente de outra unidade.
- **RNF12** Consentimento explícito do cliente no cadastro, com finalidade declarada, único para a rede.
- **RNF13** Direitos de acesso, correção e exclusão pelo portal do cliente, respeitada a guarda legal dos contratos.
- **RNF14** *(revisada na v1.4)* A exclusão de dados pessoais é sempre feita por **anonimização irreversível**, com ou sem contrato vigente: o cadastro permanece sem nenhum dado pessoal, preservando as referências dos demais registros.
- **RNF15** Retenção do histórico técnico do veículo por 10 anos, vinculado ao veículo e separado dos dados pessoais.

### 8.4 Usabilidade
- **RNF16** Sistema do Mecânico otimizado para tablet e celular, com uso em ambiente de oficina (leitura em baixa luz, operação com luvas).
- **RNF17** Portal do Cliente responsivo, nas versões web e mobile.

---

## 9. Registro de Decisões

| ID | Decisão |
|----|---------|
| D1 | Criação do Backoffice, com visão de franqueado e de matriz |
| D2 | Preços definidos pela matriz, em tabela única da rede |
| D3 | Base de clientes e veículos unificada na rede |
| D4 | Histórico técnico e alertas visíveis à rede; dados pessoais restritos à unidade em atendimento |
| D5 | Jornada padrão de 9 etapas validada *(ampliada para 10 etapas pela D68)* |
| D6 | Orçamento e contrato são artefatos separados |
| D7 | Serviço adicional exige aprovação do cliente |
| D8 | Contrato com assinatura digital |
| D9 | Aprovação de adicionais pelo portal, com notificação por e-mail |
| D10 | Sem resposta em 24h, prossegue-se com o escopo contratado |
| D11 | O adicional não expira enquanto o veículo estiver na loja |
| D12 | Adicional impeditivo pausa o serviço |
| D13 | O chefe de oficina atribui os mecânicos *(revisada)* |
| D14 | O chefe define se o veículo terá um ou vários mecânicos |
| D15 | Registro de etapas, peças com número de série, horas, fotos e observações |
| D16 | Fila ordenada por data de início do contrato *(revisada pela D89: data de entrada na fila)* |
| D17 | O chefe pode reordenar a fila |
| D18 | Devoluções e repasses passam pela decisão do chefe |
| D19 | Peças provenientes de fornecedores parceiros |
| D20 | Pedido de peça feito pelo chefe, com notificação ao cliente |
| D21 | Matriz homologa fornecedores e negocia preços das peças |
| D22 | Pedido gerado e enviado automaticamente pelo sistema |
| D23 | Estoque por franquia, sem transferência entre unidades |
| D24 | Alerta de estoque mínimo, parametrizado pela matriz |
| D25 | Controle de qualidade executado pelo chefe de oficina |
| D26 | 10% de sinal, 90% na entrega; cartão, dinheiro e Pix |
| D27 | Desistência em até 24h após a assinatura, com devolução integral *(revisada pela D68)* |
| D28 | Adicionais somam ao saldo final *(revisada pela D71: apenas os aprovados durante a execução)* |
| D29 | Todos os pagamentos são feitos na loja |
| D30 | Programa de fidelidade baseado em cashback |
| D31 | Matriz define as regras e absorve o custo do cashback |
| D32 | Devolução do sinal via Pix |
| D33 | Cashback de 5% |
| D34 | Crédito após quitação total, validade de 12 meses |
| D35 | Uso restrito ao pagamento final, limitado a 30% |
| D36 | Base de cálculo exclui a parcela paga com cashback |
| D37 | Cálculo automático de royalties, taxa de marketing e reembolso de cashback |
| D38 | Escopo do painel do franqueado |
| D39 | Escopo do painel da matriz |
| D40 | Fechamento mensal com percentuais parametrizáveis |
| D41 | Matriz com acesso somente leitura à operação |
| D42 | Escopo da trilha de auditoria |
| D43 | Inclusão dos perfis de administrador de TI e financeiro da franquia |
| D44 | Autocadastro do cliente pelo site ou app |
| D45 | Portal do cliente em web e mobile |
| D46 | Franqueado gerencia os usuários da própria unidade |
| D47 | Identificação do cliente por documento e e-mail, com alerta de duplicidade |
| D48 | Escopo do site institucional |
| D49 | Modo contingência offline no Sistema do Mecânico |
| D50 | Parcelamento exclusivo no cartão de crédito |
| D51 | Parcelamento em até 12x, limite definido pela matriz |
| D52 | O parcelamento tem juros |
| D53 | O sinal de 10% é sempre à vista, não parcelável *(revisada)* |
| D54 | RN04 passa a tratar "aprovação da transação", eliminando o conceito de formalização |
| D55 | Taxa de juros definida pela matriz |
| D56 | Faixa sem juros definida pela matriz |
| D57 | Garantia em duas coberturas: mão de obra (rede) e peça (fabricante) *(revisada pela D75: mão de obra pela franquia de origem)* |
| D58 | Exclusões de garantia definidas |
| D59 | Garantia acionável em qualquer franquia |
| D60 | Custo do reparo em garantia ressarcido pela matriz *(substituída pela D75)* |
| D61 | Chefe avalia a garantia; contestação sobe para a matriz |
| D62 | Serviço reprovado no CQ retorna ao mesmo mecânico |
| D63 | Lembretes a cada 3 dias, alerta ao gerente em 7, taxa de permanência a partir de 15 |
| D64 | Taxa de permanência não incide em "Aguardando peça" |
| D65 | Integração híbrida com fornecedores; e-mail estruturado na primeira fase |
| D66 | Agendamento online é solicitação de contato, sem reserva de capacidade |
| D67 | Parâmetros iniciais definidos (seção 7) |
| D68 | Prazo de desistência de 24h como carência: o serviço só entra na fila e só pode ser iniciado após o prazo (altera RN04, RN05) |
| D69 | Atribuição pelo chefe e início pelo mecânico são eventos distintos; a execução começa quando o primeiro mecânico inicia |
| D70 | Falta de peça e espera pelo cliente podem bloquear o serviço ao mesmo tempo; a taxa de permanência fica suspensa enquanto houver peça pendente (altera RN03, RN13, E3) |
| D71 | Adicional aprovado após a execução gera nova OS, reprecificada pela tabela vigente (altera RN01, RN04, D28) |
| D72 | Regras de veículo parado aplicadas também ao veículo pronto e não retirado (altera RN13) |
| D73 | Encerramento parcial por recusa de adicional impeditivo, com CQ de segurança, devolução da diferença via Pix e sem garantia de mão de obra (nova RN14, altera RN12) |
| D74 | Recusa tácita do impeditivo e abandono de veículo, com encaminhamento ao jurídico e remoção para pátio (nova RN15) |
| D75 | A franquia que executou o serviço original arca com a mão de obra da garantia; a matriz apenas intermedeia créditos e débitos entre franquias (altera RN10, RN11, D57, D60, RF64) |
| D76 | Troca de peça em garantia feita pelo fornecedor, por pedido gerado no sistema (altera RN11, RF54) |
| D77 | Adicional validado pelo chefe antes de chegar ao cliente, com prazo e alerta ao gerente (nova RN17, altera RN01, RN02) |
| D78 | Reparo em garantia executado como OS de garantia, sem sinal nem prazo de desistência (nova RN18) |
| D79 | Elegibilidade da garantia calculada apenas em caráter informativo; decisão sempre do chefe; prazo de contestação parametrizado |
| D80 | Orçamento com validade parametrizada, contada da apresentação e reiniciada a cada nova versão (nova RN16) |
| D81 | Ciclo de vida modelado em quatro máquinas de estado: Ordem de Serviço (nasce na assinatura), Adicional, Chamado de garantia e Orçamento; o cliente não deixa a loja sem pagar o sinal, e o contrato não pago pode ser cancelado *(ampliada pela D99)* |
| D82 | Uma OS por serviço: um orçamento com vários serviços gera um contrato e uma OS para cada serviço (nova RN19) |
| D83 | Sinal único de 10% sobre o total do contrato; desistência vale para o contrato inteiro (altera RN04, RN05) |
| D84 | Pagamento final único por contrato, quando todas as OS terminam; o veículo sai uma vez (altera RN04, RN13, RF09) *(ampliada pela D103: único por atendimento)* |
| D85 | Descontos só por campanhas da matriz, aplicadas automaticamente, não cumulativas (altera RN08; novo RF79) |
| D86 | Somente pessoa física maior de 18 anos; documento único (CPF ou passaporte), substituível; e-mail único na rede (nova RN20, altera RF01, RF23) |
| D87 | Consentimento LGPD único para a rede; cadastro global do cliente com vínculo por franquia (nova RN20) |
| D88 | Veículo identificado pelo VIN de 17 caracteres; placa e RENAVAM com histórico (altera RF03) |
| D89 | Fila ordenada pela data de entrada na fila (fim do prazo de desistência). Resolve a pendência P1 (altera RN09, RF14, D16) |
| D90 | OS do mesmo veículo podem ser executadas em paralelo (altera RN09) |
| D91 | Controle de qualidade por checklist da matriz, por categoria de serviço, com checklist "seguro para rodar" no encerramento parcial (altera RF21; novo RF80) |
| D92 | Avaliação técnica feita pelo chefe de oficina, com quilometragem de entrada, observações, fotos e serviços recomendados (novo RF77; altera a jornada) |
| D93 | Mão de obra por horas estimadas × valor-hora por categoria de serviço e tipo de veículo; peça por custo do fornecedor de referência + margem por categoria de peça; tabela de preços versionada (altera RN08, RF39, RF40) |
| D94 | Horas lançadas manualmente pelo mecânico, com limite diário; baixa de estoque na hora em que a peça instalada é registrada (nova RN22) |
| D95 | Sincronização offline: registros de fato sempre aceitos, comandos validados contra o estado da OS; limite de 3 horas offline (altera RNF06; nova RN22; resolve E4) |
| D96 | Transferência de propriedade registrada pelo atendente, com notificação ao dono anterior; o dono anterior vê o histórico apenas do seu período (nova RN21, altera RF27; novo RF76) |
| D97 | Exclusão de dados pessoais sempre por anonimização irreversível (altera RNF14) |
| D98 | Cashback com reserva no pagamento final, consumida na aprovação ou liberada no cancelamento (altera RN06) |
| D99 | Nova máquina de estados do Atendimento do veículo; a OS termina em Concluída ou Encerrada parcialmente, e pagamento final, devolução, jurídico, pátio e retirada passam ao atendimento (altera D81, RN13, RN15) |
| D100 | Chave Pix de devolução guardada com a própria devolução, criptografada, e apagada na anonimização (complementa RF58, E2) |
| D101 | Sinal e pagamento final podem combinar mais de uma forma de pagamento; a cobrança só é quitada quando as transações aprovadas cobrem o devido (altera RN04) |
| D102 | Os juros do parcelamento entram no faturamento da franquia e na base de royalties e taxa de marketing (altera RN10) |
| D103 | Adicional aprovado com o veículo pronto e ainda na loja gera novo contrato e nova OS no mesmo atendimento, que volta a "Em serviço"; o pagamento final passa a ser único por atendimento. Resolve a pendência P5 (altera RN04, RN19, RF09) |
| D104 | Controle de caixa por sessão do atendente, com suprimento, sangria, conferência do fechamento pelo gerente; pagamento em dinheiro exige caixa aberto (novo RF81) |
| D105 | Cashback calculado sem os juros do parcelamento; cada crédito tem validade própria de 12 meses e o uso consome primeiro os mais antigos; reserva expira em 30 minutos, renovados a cada tentativa (altera RN06) |
| D106 | Na garantia de peça, a mão de obra de reinstalação também é custeada pela franquia de origem (altera RN11) |
| D107 | Compensação entre franquias valorizada por horas lançadas na OS de garantia × valor-hora da tabela vigente na data do reparo, pela categoria do serviço e tipo do veículo (altera RN11, RN10) |
| D108 | Chamado de garantia é concluído normalmente mesmo que a OS de garantia termine por abandono; a compensação entre franquias ocorre e o abandono segue o fluxo do atendimento. Resolve a pendência P4 |
| D109 | Estoque mínimo apenas alerta; o pedido de reposição é decisão do chefe de oficina (altera RF36) |
| D110 | Recebimento de peças conferido pelo chefe de oficina, com quantidade, número de série e nota fiscal (novo RF82) |
| D111 | Chefe de oficina e gerente são perfis distintos: o chefe cuida dos mecânicos e o gerente cuida da loja; cada usuário tem um único perfil (separa o perfil Franqueado/Gerente; altera seção 3, RF11) |
| D112 | Colaborador lotado em uma única unidade por vez; franqueado com um login para todas as suas lojas (altera RNF09) |
| D113 | Cada mecânico com login próprio; tablets cadastrados como dispositivos da franquia (altera RNF09) |
| D114 | Fechamento em regime de caixa; saldo a favor da franquia é pago pela matriz no próprio mês, sem crédito para o mês seguinte; eventos atrasados entram como ajuste no mês aberto (altera RN10) |
| D115 | Notificações ao cliente também por SMS e WhatsApp, com opt-in; avisos obrigatórios (veículo parado, taxa de permanência, abandono) por todos os canais disponíveis, com prova de entrega (altera RF25) |
| D116 | Alertas internos para gerente, chefe e demais colaboradores na central de avisos e por e-mail (altera RF63, RF36, RF74) |
| D117 | Auditoria consultável por franquia e período, por registro e por usuário, e acessos a dados pessoais consultáveis por cliente (altera RF47) |

---

## 10. Exceções e Pontos de Atenção

Itens que fogem à regra geral e merecem atenção na implementação.

| # | Item | Observação |
|---|------|-----------|
| E1 | Matriz com acesso operacional | A D41 estabelece acesso somente leitura, mas a RN11 dá à matriz poder de decisão sobre garantias contestadas. É uma exceção controlada e deve ser auditada. |
| E2 | Pagamento fora da loja | A D29 determina que todo pagamento ocorre na loja, mas as devoluções saem via Pix (D32, RN14). O sistema registra a chave Pix do cliente nesses momentos, junto da própria devolução (D100). |
| E3 | Taxa de permanência | Incide em "Aguardando cliente" apenas nos dias sem peça pendente, e no atendimento "Aguardando pagamento final" (D64, D70, D72). Cobrar durante espera de peça ou validação interna geraria conflito, já que a espera é responsabilidade da oficina. |
| E4 | Sincronização offline | Resolvida pela D95: fatos sempre aceitos (marcados como tardios quando for o caso) e comandos validados contra o estado da OS. |
| E5 | Integração heterogênea | O modelo híbrido (D65) implica três caminhos de integração com comportamentos distintos de confirmação de recebimento. |
| E6 | Remoção para pátio | Pátios policiais normalmente recebem veículos por infração ou ordem judicial, não por solicitação de empresa privada. O caminho de remoção precisa ser validado pelo jurídico (P2). Para o sistema, a remoção é um evento registrado manualmente. |
| E7 | Adicionais simultâneos | Uma OS pode ter vários adicionais, cada um com seu próprio ciclo de vida. A OS permanece em "Aguardando cliente" enquanto houver pelo menos um impeditivo pendente. |
| E8 | Saldo invertido | No encerramento parcial, a taxa de permanência é abatida da devolução; se for maior que a diferença, o saldo passa a ser cobrado. A decisão entre cobrar e devolver é tomada no momento da retirada. |
| E9 | OS paralelas e veículo único | Com uma OS por serviço, o veículo só fica pronto quando a última OS do contrato termina. Uma OS atrasada segura a retirada e o início da taxa de permanência de todo o atendimento. |

---

## 11. Máquinas de Estado

As transições válidas, os eventos temporais e os efeitos colaterais estão formalizados em cinco diagramas UML de estado, com código PlantUML versionável (`os.puml`, `atendimento.puml`, `adicional.puml`, `garantia.puml`, `orcamento.puml` e o estilo compartilhado `estilo.iuml`).

| Máquina | Estados | Destaques |
|---|---|---|
| **Ordem de Serviço** *(revisada na v1.4)* | Aguardando sinal, Em prazo de desistência, Na fila, Atribuída, Em execução (composto), Em CQ; finais: Concluída, Encerrada parcialmente, Cancelada, Desistida | Uma OS por serviço do contrato; escolha inicial entre OS de serviço e de garantia; "Em execução" com três regiões ortogonais (trabalho, cliente, peça); CQ por checklist |
| **Atendimento do veículo** *(nova na v1.4)* | Em serviço, Aguardando pagamento final, Aguardando devolução, Encaminhado ao jurídico, Removido para pátio; finais: Entregue, Cancelado, Desistido, Encerrado por abandono | Agrupa as OS de um ou mais contratos (ou a OS de garantia); pagamento final único, taxa de permanência do veículo pronto, jurídico, pátio e retirada; atributo `tipoEncerramento` (normal, parcial, desistência) |
| **Adicional** | Registrado, Aguardando validação, Aguardando decisão, Aprovado; finais: Executado, Rejeitado, Convertido em nova OS, Recusado, Recusado tacitamente, Encerrado sem resposta | Validação do chefe antes do cliente; aprovação tardia vira nova OS |
| **Chamado de garantia** | Aberto, Em avaliação, Recusado, Em análise na matriz, Em reparo; finais: Concluído, Recusado em definitivo | Cobertura (mão de obra ou peça) na decisão; reparo via OS de garantia; compensação entre franquias |
| **Orçamento** | Em elaboração, Apresentado; finais: Aprovado, Recusado, Expirado | Versionamento e validade |

---

## 12. Pendências

| # | Pendência | Responsável |
|---|-----------|-------------|
| ~~P1~~ | ~~Definir se a ordenação da fila usa a data de assinatura do contrato ou a data de entrada na fila~~ — resolvida pela D89: data de entrada na fila | Product Owner |
| P2 | Validar com o jurídico o procedimento de remoção de veículo abandonado para pátio (E6) | Jurídico |
| P3 | Definir os valores dos parâmetros marcados como "a definir" na seção 7 | Matriz |
| ~~P4~~ | ~~Definir o comportamento do chamado de garantia quando a OS de garantia terminar por abandono~~ — resolvida pela D108 | Product Owner |
| ~~P5~~ | ~~Confirmar se o adicional aprovado com o veículo pronto gera o novo contrato no mesmo atendimento~~ — resolvida pela D103 | Product Owner |

---

## 13. Próximos Passos

Os requisitos de negócio estão fechados e as máquinas de estado, revisadas. A sequência sugerida para a especificação técnica é:

1. ~~**Máquina de estados do serviço**~~ — concluída na v1.3 e revisada na v1.4 (seção 11).
2. ~~**Modelo de dados**~~ — concluído na v1.4 (seção 14): 15 domínios e o mapa de contexto.
3. **Histórias de usuário com critérios de aceite** — desdobramento dos requisitos funcionais em itens executáveis, usando as transições dos diagramas como fonte dos critérios.
4. **Ordem de construção** — sequenciamento por dependência técnica, partindo do ciclo mínimo de valor (cliente, orçamento, contrato, execução, entrega, histórico).
5. **Arquitetura de soluções e de integração** — agrupamento dos domínios em serviços, assinatura digital, adquirente de cartão, Pix, modelo híbrido de fornecedores e publicação de eventos nos domínios em Cassandra.
6. ~~**Estratégia de sincronização offline**~~ — definida na v1.4 (D95, RN22); detalhes de implementação ficam para a arquitetura.

---

## 14. Modelo de Dados

O modelo de dados é organizado **por domínio**, com um diagrama ER em PlantUML para cada um (pasta `modelo-de-dados/`, estilo em `estilo-er.iuml`). As decisões técnicas estão registradas em `modelo-de-dados/decisoes.md` (DM1 em diante).

**Princípios**
- Cada domínio é dono dos seus dados; outros domínios guardam apenas o identificador, sem chave estrangeira física, e a integridade entre domínios é mantida por eventos (outbox + CDC) e sagas.
- A consistência é escolhida por contexto segundo o PACELC: forte para dinheiro, estado da OS, estoque, cadastro e cashback; eventual, com versão, para histórico, catálogo, execução, portal e notificações.
- **Persistência poliglota**: YugabyteDB (SQL distribuído) nos domínios de consistência forte; Cassandra em Execução, Histórico técnico, Auditoria e Notificações.
- Dados de uma franquia ficam na região dela; dados da rede ficam globais. Regiões apenas no Brasil (LGPD).
- **Dados pessoais somente no domínio de Clientes**, com a única exceção da chave Pix de devolução (D100). O histórico técnico do veículo não guarda identificação do cliente (RNF15).

| Domínio | Banco | Diagrama |
|---|---|---|
| Clientes | YugabyteDB | `clientes.puml` |
| Veículos | YugabyteDB (cadastro) + Cassandra (histórico) | `veiculos.puml` |
| Rede | YugabyteDB | `rede.puml` |
| Catálogo e Preços | YugabyteDB | `catalogo.puml` |
| Comercial | YugabyteDB | `comercial.puml` |
| Ordem de Serviço | YugabyteDB | `os.puml` |
| Execução | Cassandra | `execucao.puml` |
| Pagamentos | YugabyteDB | `pagamentos.puml` |
| Cashback | YugabyteDB (global) | `cashback.puml` |
| Garantia | YugabyteDB | `garantia.puml` |
| Suprimentos | YugabyteDB | `suprimentos.puml` |
| Identidade e Acesso | YugabyteDB (global) | `identidade.puml` |
| Fechamento | YugabyteDB (região da matriz) | `fechamento.puml` |
| Notificações | Cassandra | `notificacoes.puml` |
| Auditoria | Cassandra | `auditoria.puml` |

O relacionamento entre os domínios, com os principais eventos, está em `mapa-de-contexto.puml`.

Há uma versão em inglês do modelo, com o mesmo conteúdo e nomes de tabelas, colunas e valores prontos para o código, na pasta `data-model/`. O arquivo `data-model/glossary.md` faz a correspondência PT ↔ EN.
